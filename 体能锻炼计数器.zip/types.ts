export enum ExerciseType {
  KETTLEBELL_SWING = '荡壶铃',
  GOBLET_SQUAT = '蹲据壶铃',
  PUSH_UP = '俯卧撑',
  PULL_UP = '引体向上',
  BURPEE = '波比跳'
}

export interface Plan {
  exercise: string;
  customExerciseName?: string;
  repsPerSet: number;
  dailyTargetSets: number;
  repsConfig?: Record<string, number>;
}

export interface DailyLog {
  [dateString: string]: {
    completedSets: number;
    completed: boolean;
  };
}

export const EXERCISE_OPTIONS = [
  ExerciseType.KETTLEBELL_SWING,
  ExerciseType.GOBLET_SQUAT,
  ExerciseType.PUSH_UP,
  ExerciseType.PULL_UP,
  ExerciseType.BURPEE
];
