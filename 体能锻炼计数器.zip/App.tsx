import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { PlanSettings } from './components/PlanSettings';
import { Tracker } from './components/Tracker';
import { Statistics } from './components/Statistics';
import { getStoredPlan, savePlan, getStoredLogs, saveLog } from './services/storage';
import { Plan, DailyLog } from './types';

const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<'tracker' | 'stats' | 'settings'>('tracker');
  const [plan, setPlan] = useState<Plan>(getStoredPlan());
  const [logs, setLogs] = useState<DailyLog>(getStoredLogs());
  const [todayCompleted, setTodayCompleted] = useState(0);

  // Initialize today's data
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (logs[today]) {
      setTodayCompleted(logs[today].completedSets);
    } else {
      setTodayCompleted(0);
    }
  }, [logs]);

  const handlePlanSave = (newPlan: Plan) => {
    setPlan(newPlan);
    savePlan(newPlan);
    setCurrentTab('tracker');
  };

  const handleIncrement = () => {
    const today = new Date().toISOString().split('T')[0];
    const newCount = todayCompleted + 1;
    setTodayCompleted(newCount);
    
    const updatedLogs = saveLog(today, newCount, plan.dailyTargetSets);
    setLogs(updatedLogs);
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'settings':
        return <PlanSettings currentPlan={plan} onSave={handlePlanSave} />;
      case 'stats':
        return <Statistics logs={logs} />;
      case 'tracker':
      default:
        return (
          <Tracker 
            plan={plan} 
            completedSets={todayCompleted} 
            onIncrement={handleIncrement} 
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans selection:bg-blue-100">
      <div className="max-w-md mx-auto min-h-screen bg-white shadow-2xl overflow-hidden relative">
        {renderContent()}
        <Navbar currentTab={currentTab} onTabChange={setCurrentTab} />
      </div>
    </div>
  );
};

export default App;
