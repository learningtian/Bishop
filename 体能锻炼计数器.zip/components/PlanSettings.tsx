import React, { useState, useEffect } from 'react';
import { Plan, EXERCISE_OPTIONS, ExerciseType } from '../types';
import { Button } from './Button';
import { CheckCircle2, Edit3 } from 'lucide-react';

interface PlanSettingsProps {
  currentPlan: Plan;
  onSave: (plan: Plan) => void;
}

export const PlanSettings: React.FC<PlanSettingsProps> = ({ currentPlan, onSave }) => {
  const [selectedType, setSelectedType] = useState<string>('');
  const [customName, setCustomName] = useState<string>('');
  const [repsMap, setRepsMap] = useState<Record<string, number>>({});
  const [sets, setSets] = useState(currentPlan.dailyTargetSets);
  const [saved, setSaved] = useState(false);

  // Initialize state from current plan
  useEffect(() => {
    // Determine if current exercise is in the preset list
    const isPreset = EXERCISE_OPTIONS.includes(currentPlan.exercise as ExerciseType);
    
    if (isPreset) {
      setSelectedType(currentPlan.exercise);
      setCustomName(currentPlan.customExerciseName || '');
    } else {
      setSelectedType('CUSTOM');
      setCustomName(currentPlan.exercise);
    }

    // Initialize reps map, ensuring current exercise has its value
    const initialRepsMap = { ...currentPlan.repsConfig };
    if (!initialRepsMap[currentPlan.exercise]) {
      initialRepsMap[currentPlan.exercise] = currentPlan.repsPerSet;
    }
    setRepsMap(initialRepsMap);
  }, [currentPlan]);

  const getCurrentReps = () => {
    const key = selectedType === 'CUSTOM' ? customName : selectedType;
    // Allow 0 as a valid value, default to 10 if undefined
    const val = repsMap[key];
    return val !== undefined ? val : 10;
  };

  const handleRepsChange = (newReps: number) => {
    const key = selectedType === 'CUSTOM' ? customName : selectedType;
    // Allow saving reps even for empty custom name temporarily to prevent UI freezing
    const safeKey = key || '';
    
    setRepsMap(prev => ({
      ...prev,
      [safeKey]: newReps
    }));
  };

  const handleSave = () => {
    const finalExerciseName = selectedType === 'CUSTOM' ? (customName.trim() || '自定义运动') : selectedType;
    
    // Use the current visible reps value directly. 
    // This handles cases where the user didn't touch the slider (so it's not in repsMap yet)
    // or if there are key mismatches (e.g. trailing spaces in customName vs trimmed finalName).
    const finalReps = getCurrentReps();
    
    // Ensure the map includes the final config for this exercise
    const updatedRepsMap = {
        ...repsMap,
        [finalExerciseName]: finalReps
    };

    onSave({
      exercise: finalExerciseName,
      customExerciseName: customName,
      repsPerSet: finalReps,
      dailyTargetSets: sets,
      repsConfig: updatedRepsMap
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const currentReps = getCurrentReps();

  return (
    <div className="p-6 space-y-8 max-w-md mx-auto pb-24 animate-fade-in">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-gray-900">制定锻炼计划</h2>
        <p className="text-gray-500">设定你的目标，坚持每天打卡。</p>
      </div>

      <div className="space-y-6 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <div className="space-y-3">
          <label className="text-sm font-semibold text-gray-700">选择锻炼项目</label>
          <div className="grid grid-cols-1 gap-2">
            {EXERCISE_OPTIONS.map((opt) => (
              <button
                key={opt}
                onClick={() => setSelectedType(opt)}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                  selectedType === opt 
                    ? 'border-blue-500 bg-blue-50 text-blue-700' 
                    : 'border-gray-200 text-gray-600 hover:border-blue-200'
                }`}
              >
                <span>{opt}</span>
                {selectedType === opt && <CheckCircle2 size={18} />}
              </button>
            ))}
            
            {/* Custom Option Button */}
            <button
                onClick={() => setSelectedType('CUSTOM')}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                  selectedType === 'CUSTOM'
                    ? 'border-blue-500 bg-blue-50 text-blue-700' 
                    : 'border-gray-200 text-gray-600 hover:border-blue-200'
                }`}
              >
                <div className="flex items-center gap-2">
                   <Edit3 size={16} />
                   <span>自定义项目</span>
                </div>
                {selectedType === 'CUSTOM' && <CheckCircle2 size={18} />}
              </button>
          </div>

          {/* Custom Name Input */}
          {selectedType === 'CUSTOM' && (
             <div className="mt-2 animate-fade-in">
                <label className="text-xs text-gray-500 ml-1">项目名称</label>
                <input 
                  type="text" 
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="请输入运动名称 (例如: 平板支撑)"
                  className="w-full mt-1 p-3 rounded-xl border border-blue-300 focus:ring-2 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all"
                />
             </div>
          )}
        </div>

        <div className="space-y-6 pt-2 border-t border-gray-50">
          {/* Reps Setting (Per Exercise) */}
          <div className="space-y-2">
            <div className="flex justify-between items-end">
              <label className="text-sm font-semibold text-gray-700">
                每组次数 
                <span className="text-xs font-normal text-gray-400 ml-2">
                  (针对: {selectedType === 'CUSTOM' ? (customName || '自定义') : selectedType})
                </span>
              </label>
              <span className="text-blue-600 font-bold text-lg">{currentReps} 次</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={currentReps}
              onChange={(e) => handleRepsChange(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-xs text-gray-400">
                <span>0</span>
                <span>100</span>
            </div>
          </div>

          {/* Daily Sets Setting (Global) */}
          <div className="space-y-2">
            <div className="flex justify-between items-end">
              <label className="text-sm font-semibold text-gray-700">每天目标组数</label>
              <span className="text-blue-600 font-bold text-lg">{sets} 组</span>
            </div>
            <input
              type="range"
              min="1"
              max="20"
              value={sets}
              onChange={(e) => setSets(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-xs text-gray-400">
                <span>1</span>
                <span>20</span>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
         <div className="bg-orange-50 p-4 rounded-xl border border-orange-100">
            <h4 className="font-medium text-orange-800 text-sm mb-1">📅 智能提醒已开启</h4>
            <p className="text-orange-600 text-xs">
              若未完成目标，App 将在 10:00, 16:00, 22:00 发送提醒。
            </p>
         </div>

        <Button onClick={handleSave} fullWidth disabled={saved}>
          {saved ? '已保存计划' : '保存设置'}
        </Button>
      </div>
    </div>
  );
};