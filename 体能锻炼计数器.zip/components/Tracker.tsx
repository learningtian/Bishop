import React, { useState, useEffect, useRef } from 'react';
import { Plan } from '../types';
import { ConfettiEffect } from './ConfettiEffect';
import { Volume2, Music, Palette, Disc, Check } from 'lucide-react';

interface TrackerProps {
  plan: Plan;
  completedSets: number;
  onIncrement: () => void;
}

// Configuration Constants
const CHAR_OPTIONS = [
  { 
    id: 'pink', 
    name: '甜心粉', 
    hairColor: 'bg-pink-300', 
    hairBorder: 'border-pink-400', 
    outfitColor: 'bg-blue-500', 
    accessoryColor: 'bg-red-500',
    style: 'pigtails'
  },
  { 
    id: 'purple', 
    name: '高冷紫', 
    hairColor: 'bg-purple-400', 
    hairBorder: 'border-purple-600', 
    outfitColor: 'bg-indigo-600', 
    accessoryColor: 'bg-yellow-400',
    style: 'long'
  },
  { 
    id: 'blonde', 
    name: '元气黄', 
    hairColor: 'bg-yellow-200', 
    hairBorder: 'border-yellow-400', 
    outfitColor: 'bg-pink-500', 
    accessoryColor: 'bg-blue-400',
    style: 'short'
  },
  { 
    id: 'mint', 
    name: '清新绿', 
    hairColor: 'bg-emerald-300', 
    hairBorder: 'border-emerald-500', 
    outfitColor: 'bg-orange-400', 
    accessoryColor: 'bg-white',
    style: 'pigtails'
  },
];

const MUSIC_OPTIONS = [
  { id: 'happy', name: '欢快', url: 'https://assets.mixkit.co/active_storage/sfx/1120/1120-preview.mp3' },
  { id: 'funky', name: '动感', url: 'https://assets.mixkit.co/active_storage/sfx/1114/1114-preview.mp3' },
  { id: 'dreamy', name: '梦幻', url: 'https://assets.mixkit.co/active_storage/sfx/265/265-preview.mp3' },
  { id: 'arcade', name: '电玩', url: 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3' },
];

export const Tracker: React.FC<TrackerProps> = ({ plan, completedSets, onIncrement }) => {
  const [confettiTrigger, setConfettiTrigger] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const [isBumping, setIsBumping] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [ripples, setRipples] = useState<number[]>([]);
  
  // Customization State (with simple persistence)
  const [activeCharId, setActiveCharId] = useState(() => localStorage.getItem('fitness_pref_char') || 'pink');
  const [activeMusicId, setActiveMusicId] = useState(() => localStorage.getItem('fitness_pref_music') || 'happy');

  const activeChar = CHAR_OPTIONS.find(c => c.id === activeCharId) || CHAR_OPTIONS[0];

  const remainingSets = Math.max(0, plan.dailyTargetSets - completedSets);
  const progress = Math.min(100, (completedSets / plan.dailyTargetSets) * 100);

  // Audio refs
  const clickAudio = useRef<HTMLAudioElement | null>(null);
  const musicAudio = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Initialize Audio
    clickAudio.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2578/2578-preview.mp3');
    
    // Set initial music track
    const track = MUSIC_OPTIONS.find(t => t.id === activeMusicId) || MUSIC_OPTIONS[0];
    musicAudio.current = new Audio(track.url);
    if (musicAudio.current) {
        musicAudio.current.loop = true;
    }
  }, []); // Run once on mount

  // Handle Music Switching
  useEffect(() => {
    if (!musicAudio.current) return;
    
    const track = MUSIC_OPTIONS.find(t => t.id === activeMusicId);
    if (track && musicAudio.current.src !== track.url) {
        musicAudio.current.src = track.url;
        musicAudio.current.load();
        if (showCelebration) {
            musicAudio.current.play().catch(e => console.log("Playback failed", e));
        }
    }
    localStorage.setItem('fitness_pref_music', activeMusicId);
  }, [activeMusicId, showCelebration]);

  // Handle Char Persistence
  useEffect(() => {
    localStorage.setItem('fitness_pref_char', activeCharId);
  }, [activeCharId]);

  const handleClick = () => {
    // Trigger animations
    setIsBumping(true);
    setIsShaking(true);
    setTimeout(() => setIsShaking(false), 300);
    
    const rippleId = Date.now();
    setRipples(prev => [...prev, rippleId]);
    setTimeout(() => {
        setRipples(prev => prev.filter(id => id !== rippleId));
    }, 600);

    onIncrement();
    setConfettiTrigger(prev => prev + 1);
    
    if (clickAudio.current) {
      clickAudio.current.currentTime = 0;
      clickAudio.current.play().catch(e => console.log("Audio play blocked", e));
    }

    if (completedSets + 1 === plan.dailyTargetSets) {
       setShowCelebration(true);
       setTimeout(() => {
           if (musicAudio.current) musicAudio.current.play().catch(e => console.log("Audio play blocked", e));
       }, 500);
    }
  };

  const closeCelebration = () => {
      setShowCelebration(false);
      if (musicAudio.current) {
          musicAudio.current.pause();
          musicAudio.current.currentTime = 0;
      }
  };

  return (
    <div className={`h-full flex flex-col p-6 pb-24 max-w-md mx-auto relative overflow-hidden transition-transform ${isShaking ? 'animate-shake' : ''}`}>
      <style>{`
        @keyframes screen-shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-4px) rotate(-1deg); }
          40% { transform: translateX(4px) rotate(1deg); }
          60% { transform: translateX(-2px); }
          80% { transform: translateX(2px); }
        }
        .animate-shake { animation: screen-shake 0.3s cubic-bezier(.36,.07,.19,.97) both; }

        @keyframes dance-bounce {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(2deg); }
        }
        @keyframes hair-sway-left {
          0%, 100% { transform: rotate(10deg); }
          50% { transform: rotate(25deg); }
        }
        @keyframes hair-sway-right {
          0%, 100% { transform: rotate(-10deg); }
          50% { transform: rotate(-25deg); }
        }
        @keyframes hair-sway-long {
          0%, 100% { transform: rotate(2deg); }
          50% { transform: rotate(-2deg); }
        }
        @keyframes float-note {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          20% { opacity: 1; }
          100% { transform: translateY(-100px) rotate(20deg); opacity: 0; }
        }
        .animate-dance { animation: dance-bounce 0.4s infinite cubic-bezier(0.37, 0, 0.63, 1); }
        .animate-hair-left { animation: hair-sway-left 0.8s infinite ease-in-out; }
        .animate-hair-right { animation: hair-sway-right 0.8s infinite ease-in-out; }
        .animate-hair-long { animation: hair-sway-long 2s infinite ease-in-out; }
        .animate-note-1 { animation: float-note 2s infinite linear; }
        .animate-note-2 { animation: float-note 2.5s infinite linear 0.5s; }
        .animate-note-3 { animation: float-note 3s infinite linear 1s; }
      `}</style>

      <ConfettiEffect trigger={confettiTrigger} />

      {/* Header Info */}
      <div className="mt-4 flex flex-col items-center space-y-2">
        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold tracking-wide uppercase">
          今日计划
        </span>
        <h1 className="text-3xl font-bold text-gray-900">{plan.exercise}</h1>
        <p className="text-gray-500 font-medium">每组 {plan.repsPerSet} 次</p>
      </div>

      {/* Main Status Display */}
      <div className="flex-1 flex flex-col justify-center items-center space-y-8 my-8">
        <div className="grid grid-cols-2 gap-6 w-full">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center">
             <span className="text-4xl font-bold text-blue-600 mb-1">{completedSets}</span>
             <span className="text-xs text-gray-400 font-medium">已完成(组)</span>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center">
             <span className={`text-4xl font-bold mb-1 ${remainingSets === 0 ? 'text-green-500' : 'text-gray-900'}`}>
                {remainingSets}
             </span>
             <span className="text-xs text-gray-400 font-medium">剩余(组)</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div 
                className="bg-blue-600 h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
            />
        </div>

        {/* Big Action Button Wrapper */}
        <div className="relative flex items-center justify-center">
            {ripples.map(id => (
                <div 
                  key={id} 
                  className="absolute inset-0 rounded-full border-blue-400 bg-blue-400/20 animate-ring-expand pointer-events-none z-0" 
                />
            ))}

            <button
              onClick={handleClick}
              onAnimationEnd={() => setIsBumping(false)}
              className={`relative z-10 w-48 h-48 rounded-full bg-gradient-to-b from-blue-500 to-blue-600 shadow-xl shadow-blue-200 flex items-center justify-center transition-all duration-200 ${
                isBumping ? 'animate-bump brightness-110' : 'active:scale-95 hover:shadow-2xl hover:shadow-blue-300'
              }`}
            >
              <div className="absolute inset-2 rounded-full border-2 border-white/20"></div>
              <div className="flex flex-col items-center text-white">
                  <span className="text-6xl font-black mb-1 drop-shadow-md">+1</span>
                  <span className="text-sm font-medium opacity-90">完成一组</span>
              </div>
              
              {!isBumping && (
                  <div className="absolute -inset-1 bg-blue-500/30 rounded-full animate-neon-glow pointer-events-none mix-blend-screen"></div>
              )}
            </button>
        </div>
      </div>

       {/* Celebration Overlay Modal */}
       {showCelebration && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl relative flex flex-col max-h-[90vh]">
            <button 
                onClick={closeCelebration}
                className="absolute top-4 right-4 z-20 bg-black/20 hover:bg-black/30 text-white w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-colors"
            >
                ✕
            </button>
            
            {/* Dynamic CSS Anime Scene */}
            <div className={`relative h-72 w-full flex items-end justify-center overflow-hidden transition-colors duration-700 bg-gradient-to-b ${activeChar.id === 'pink' ? 'from-indigo-400 to-purple-500' : activeChar.id === 'purple' ? 'from-purple-500 to-indigo-800' : activeChar.id === 'blonde' ? 'from-blue-400 to-teal-400' : 'from-green-400 to-emerald-600'}`}>
               
               {/* Background Elements */}
               <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent animate-pulse"></div>
               <div className="absolute top-10 right-10 text-white animate-note-1"><Music size={24} /></div>
               <div className="absolute top-20 left-10 text-white animate-note-2"><Music size={16} /></div>
               <div className="absolute top-32 right-24 text-white animate-note-3"><Music size={20} /></div>

               {/* Anime Character */}
               <div className="relative z-10 mb-8 animate-dance origin-bottom transition-all duration-300">
                  {/* Hair Style: Pigtails */}
                  {activeChar.style === 'pigtails' && (
                    <>
                      <div className={`absolute top-4 -left-8 w-10 h-24 ${activeChar.hairColor} rounded-full origin-top animate-hair-left border-2 ${activeChar.hairBorder}`}></div>
                      <div className={`absolute top-4 -right-8 w-10 h-24 ${activeChar.hairColor} rounded-full origin-top animate-hair-right border-2 ${activeChar.hairBorder}`}></div>
                    </>
                  )}
                  {/* Hair Style: Long */}
                  {activeChar.style === 'long' && (
                    <div className={`absolute top-6 -left-6 w-40 h-28 ${activeChar.hairColor} rounded-3xl origin-top animate-hair-long border-2 ${activeChar.hairBorder} -z-10`}></div>
                  )}

                  {/* Body/Dress */}
                  <div className={`absolute top-20 left-1/2 -translate-x-1/2 w-16 h-20 ${activeChar.outfitColor} rounded-t-xl z-0 flex flex-col items-center transition-colors`}>
                      {/* Collar */}
                      <div className="w-full h-8 bg-white rounded-t-xl relative border-b border-black/10">
                           <div className={`absolute top-2 left-1/2 -translate-x-1/2 w-4 h-4 ${activeChar.accessoryColor} rotate-45`}></div>
                      </div>
                      {/* Arms */}
                      <div className="absolute top-6 -left-3 w-4 h-16 bg-white rounded-full origin-top -rotate-12 border border-gray-100">
                         <div className="absolute bottom-0 w-5 h-5 bg-[#FFE0BD] rounded-full"></div>
                      </div>
                      <div className="absolute top-6 -right-3 w-4 h-16 bg-white rounded-full origin-top rotate-12 border border-gray-100 shadow-sm">
                         <div className="absolute bottom-0 w-5 h-5 bg-[#FFE0BD] rounded-full"></div>
                      </div>
                  </div>

                  {/* Head */}
                  <div className="relative w-28 h-24 bg-[#FFE0BD] rounded-[2rem] z-10 border-2 border-[#EAC09A] flex justify-center shadow-lg">
                      {/* Bangs (Dynamic Color) */}
                      <div className={`absolute -top-4 w-32 h-16 ${activeChar.hairColor} rounded-t-full border-2 ${activeChar.hairBorder} transition-colors`}></div>
                      <div className={`absolute top-0 left-4 w-6 h-8 ${activeChar.hairColor} rounded-full transition-colors`}></div>
                      <div className={`absolute top-0 right-4 w-6 h-8 ${activeChar.hairColor} rounded-full transition-colors`}></div>

                      {/* Face */}
                      <div className="absolute top-10 w-full flex justify-between px-6">
                          <div className="w-3 h-4 bg-gray-800 rounded-full relative overflow-hidden">
                             <div className="absolute top-0 left-0 w-1 h-2 bg-white rounded-full opacity-80"></div>
                          </div>
                          <div className="w-3 h-4 bg-gray-800 rounded-full relative overflow-hidden">
                             <div className="absolute top-0 left-0 w-1 h-2 bg-white rounded-full opacity-80"></div>
                          </div>
                      </div>
                      
                      <div className="absolute top-14 w-full flex justify-between px-5 opacity-40">
                          <div className="w-4 h-2 bg-red-400 rounded-full"></div>
                          <div className="w-4 h-2 bg-red-400 rounded-full"></div>
                      </div>
                      <div className="absolute bottom-6 w-4 h-2 bg-red-400 rounded-b-full border-t border-red-500"></div>
                  </div>
               </div>

               {/* Text Overlay */}
               <div className="absolute inset-0 flex items-end justify-center pb-2 pointer-events-none">
                  <div className="text-center px-6">
                      <h2 className="text-3xl font-bold text-white mb-1 animate-bounce drop-shadow-md">目标达成!</h2>
                  </div>
               </div>
            </div>

            {/* Customization Controls */}
            <div className="bg-white px-5 pt-4 pb-2 border-b border-gray-100">
               <div className="space-y-4">
                  
                  {/* Character Selector */}
                  <div className="flex items-center space-x-3 overflow-x-auto no-scrollbar pb-1">
                      <div className="shrink-0 w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                        <Palette size={14} />
                      </div>
                      {CHAR_OPTIONS.map((char) => (
                        <button
                           key={char.id}
                           onClick={() => setActiveCharId(char.id)}
                           className={`relative w-10 h-10 rounded-full border-2 flex items-center justify-center shrink-0 transition-all ${activeCharId === char.id ? 'border-blue-500 scale-110 shadow-md' : 'border-gray-100 grayscale hover:grayscale-0'}`}
                           style={{ backgroundColor: 'white' }}
                        >
                           <div className={`w-full h-full rounded-full ${char.hairColor} opacity-80`}></div>
                           {activeCharId === char.id && (
                             <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-0.5 border border-white">
                               <Check size={8} className="text-white" />
                             </div>
                           )}
                        </button>
                      ))}
                  </div>

                  {/* Music Selector */}
                  <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar pb-1">
                      <div className="shrink-0 w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                        <Disc size={14} />
                      </div>
                      {MUSIC_OPTIONS.map((music) => (
                        <button
                           key={music.id}
                           onClick={() => setActiveMusicId(music.id)}
                           className={`px-3 py-1.5 rounded-full text-xs font-medium shrink-0 transition-all ${
                             activeMusicId === music.id 
                               ? 'bg-blue-600 text-white shadow-blue-200 shadow-md' 
                               : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                           }`}
                        >
                           {music.name}
                        </button>
                      ))}
                  </div>
               </div>
            </div>

            <div className="p-5 bg-white flex-1 flex items-end">
                 <button 
                    onClick={closeCelebration}
                    className="w-full py-3 bg-gradient-to-r from-gray-800 to-gray-900 text-white rounded-xl font-bold shadow-lg shadow-gray-300 active:scale-95 transition-transform"
                 >
                    明天继续加油
                 </button>
            </div>
          </div>
          <ConfettiEffect trigger={100} /> 
        </div>
      )}
    </div>
  );
};