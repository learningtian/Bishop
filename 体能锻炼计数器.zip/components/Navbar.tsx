import React from 'react';
import { LayoutDashboard, CalendarDays, Settings } from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onTabChange: (tab: 'tracker' | 'stats' | 'settings') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onTabChange }) => {
  const tabs = [
    { id: 'tracker', icon: LayoutDashboard, label: '打卡' },
    { id: 'stats', icon: CalendarDays, label: '统计' },
    { id: 'settings', icon: Settings, label: '计划' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md border-t border-gray-200 pb-safe pt-2 px-6 shadow-lg z-40">
      <div className="flex justify-between items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as any)}
              className={`flex flex-col items-center justify-center w-16 h-14 space-y-1 transition-colors ${
                isActive ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
