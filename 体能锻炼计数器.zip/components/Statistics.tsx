import React, { useMemo, useState } from 'react';
import { DailyLog } from '../types';
import { ChevronLeft, ChevronRight, Trophy, X, Calendar } from 'lucide-react';

interface StatisticsProps {
  logs: DailyLog;
}

export const Statistics: React.FC<StatisticsProps> = ({ logs }) => {
  const today = new Date();
  const [currentDate, setCurrentDate] = useState(today);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const daysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const firstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const monthData = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysCount = daysInMonth(currentDate);
    const startDay = firstDayOfMonth(currentDate); // 0 = Sunday

    const days = [];
    // Padding for empty start days
    for (let i = 0; i < startDay; i++) {
      days.push(null);
    }
    // Actual days
    for (let i = 1; i <= daysCount; i++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
      days.push({
        day: i,
        dateString: dateStr,
        log: logs[dateStr]
      });
    }
    return days;
  }, [currentDate, logs]);

  const changeMonth = (delta: number) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() + delta);
    setCurrentDate(newDate);
  };

  const totalCompletedDays = Object.values(logs).filter((l: any) => l.completed).length;
  const totalSets = Object.values(logs).reduce((acc, curr: any) => acc + curr.completedSets, 0);

  const getSelectedDayDetails = () => {
    if (!selectedDate) return null;
    const log = logs[selectedDate];
    const dateObj = new Date(selectedDate);
    const formattedDate = `${dateObj.getFullYear()}年${dateObj.getMonth() + 1}月${dateObj.getDate()}日`;
    
    // Determine weekday
    const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    const weekday = weekdays[dateObj.getDay()];

    return {
        formattedDate,
        weekday,
        sets: log?.completedSets || 0,
        isCompleted: log?.completed || false,
        hasRecord: !!log
    };
  };

  const details = getSelectedDayDetails();

  return (
    <div className="p-6 pb-24 max-w-md mx-auto animate-fade-in relative">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-gray-900">锻炼统计</h2>
        <div className="flex items-center space-x-2 bg-white px-3 py-1 rounded-full shadow-sm border border-gray-200">
           <Trophy size={16} className="text-yellow-500" />
           <span className="text-sm font-semibold text-gray-700">累计 {totalSets} 组</span>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden mb-6">
        <div className="flex justify-between items-center p-4 border-b border-gray-100 bg-gray-50">
          <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-gray-200 rounded-full text-gray-600">
            <ChevronLeft size={20} />
          </button>
          <span className="font-bold text-gray-700">
            {currentDate.getFullYear()}年 {currentDate.getMonth() + 1}月
          </span>
          <button onClick={() => changeMonth(1)} className="p-1 hover:bg-gray-200 rounded-full text-gray-600">
            <ChevronRight size={20} />
          </button>
        </div>

        <div className="p-4">
          <div className="grid grid-cols-7 gap-2 mb-2 text-center">
            {['日', '一', '二', '三', '四', '五', '六'].map(d => (
              <div key={d} className="text-xs text-gray-400 font-medium">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-2">
            {monthData.map((d, idx) => {
              if (!d) return <div key={`empty-${idx}`} />;
              
              let bgClass = "bg-gray-50 text-gray-400 hover:bg-gray-100"; // Default / Future
              const isToday = d.dateString === new Date().toISOString().split('T')[0];
              
              if (d.log) {
                if (d.log.completed) {
                  bgClass = "bg-green-500 text-white shadow-green-200 shadow-md";
                } else if (d.log.completedSets > 0) {
                   bgClass = "bg-blue-100 text-blue-600";
                } else if (new Date(d.dateString) < new Date(today.setHours(0,0,0,0))) {
                   bgClass = "bg-red-50 text-red-300"; // Past incomplete
                }
              }

              if (isToday && !d.log?.completed) {
                 bgClass += " ring-2 ring-blue-400 ring-offset-2";
              }

              return (
                <button 
                  key={d.dateString}
                  onClick={() => setSelectedDate(d.dateString)}
                  className={`aspect-square flex flex-col items-center justify-center rounded-lg transition-all active:scale-95 ${bgClass}`}
                >
                  <span className="text-sm font-semibold leading-none">{d.day}</span>
                  {d.log && d.log.completedSets > 0 && (
                    <span className="text-[10px] mt-1 opacity-90 font-medium">
                      {d.log.completedSets}组
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
        <div className="p-4 bg-gray-50 text-xs text-gray-500 flex justify-around">
            <div className="flex items-center"><div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>达标</div>
            <div className="flex items-center"><div className="w-3 h-3 bg-blue-100 rounded-full mr-1"></div>进行中</div>
            <div className="flex items-center"><div className="w-3 h-3 bg-gray-200 rounded-full mr-1"></div>未开始</div>
        </div>
      </div>
      
      <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl p-6 text-white shadow-lg shadow-blue-200">
          <div className="text-blue-100 text-sm mb-1">本月完美达成</div>
          <div className="text-4xl font-bold">{totalCompletedDays} <span className="text-lg font-normal opacity-80">天</span></div>
      </div>

      {/* Detail Modal */}
      {selectedDate && details && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-fade-in" onClick={() => setSelectedDate(null)}>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xs p-6 relative overflow-hidden" onClick={e => e.stopPropagation()}>
                <button onClick={() => setSelectedDate(null)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                    <X size={20} />
                </button>
                
                <div className="flex items-center space-x-2 text-gray-500 mb-6">
                    <Calendar size={18} />
                    <span className="text-sm font-medium">{details.formattedDate} {details.weekday}</span>
                </div>

                <div className="flex flex-col items-center text-center space-y-2 mb-6">
                     <span className="text-sm text-gray-400 font-medium uppercase tracking-wider">完成组数</span>
                     <span className={`text-6xl font-black ${details.hasRecord ? (details.isCompleted ? 'text-green-500' : 'text-blue-600') : 'text-gray-300'}`}>
                        {details.sets}
                     </span>
                </div>

                <div className={`p-3 rounded-xl text-center text-sm font-bold ${
                    details.hasRecord 
                        ? (details.isCompleted ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700')
                        : 'bg-gray-100 text-gray-500'
                }`}>
                    {details.hasRecord 
                        ? (details.isCompleted ? '🎉 目标达成' : '🏃‍♂️ 正在努力') 
                        : '😴 暂无记录'}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};