import { Plan, DailyLog, ExerciseType } from '../types';

const PLAN_KEY = 'fitness_app_plan';
const LOG_KEY = 'fitness_app_log';

const DEFAULT_PLAN: Plan = {
  exercise: ExerciseType.KETTLEBELL_SWING,
  customExerciseName: '',
  repsPerSet: 10,
  dailyTargetSets: 5,
  repsConfig: {}
};

export const getStoredPlan = (): Plan => {
  const stored = localStorage.getItem(PLAN_KEY);
  if (!stored) return DEFAULT_PLAN;
  
  const parsed = JSON.parse(stored);
  return {
    ...DEFAULT_PLAN,
    ...parsed,
    repsConfig: parsed.repsConfig || {}
  };
};

export const savePlan = (plan: Plan): void => {
  localStorage.setItem(PLAN_KEY, JSON.stringify(plan));
};

export const getStoredLogs = (): DailyLog => {
  const stored = localStorage.getItem(LOG_KEY);
  return stored ? JSON.parse(stored) : {};
};

export const saveLog = (date: string, completedSets: number, target: number): DailyLog => {
  const logs = getStoredLogs();
  logs[date] = {
    completedSets,
    completed: completedSets >= target
  };
  localStorage.setItem(LOG_KEY, JSON.stringify(logs));
  return logs;
};
